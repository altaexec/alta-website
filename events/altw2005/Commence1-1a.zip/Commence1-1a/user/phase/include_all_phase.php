<?php

global $php_root_path ;
require_once ( "$php_root_path/user/phase/phasebase.php" ) ;
require_once ( "$php_root_path/user/phase/phase1.php" ) ;
require_once ( "$php_root_path/user/phase/phase2.php" ) ;
require_once ( "$php_root_path/user/phase/phase3.php" ) ;
require_once ( "$php_root_path/user/phase/phase4.php" ) ;
	
?>